insert into user values (10001, 'nihar@gmail.com', 'nihar', 'tripathy', '$2y$12$xXgo2sUJ1n5yVOc456r9ZuHb.zuxnvlr0x7uy.UVI8coPHZHHC.dC', '','nihar');
insert into role values (10200, 'USER ROLE', 'ROLE_USER');
insert into users_roles values(10200, 10001);
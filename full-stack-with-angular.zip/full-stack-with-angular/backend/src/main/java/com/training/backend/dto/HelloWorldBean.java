package com.training.backend.dto;

import lombok.Data;

@Data
public class HelloWorldBean {
    private String message;
}

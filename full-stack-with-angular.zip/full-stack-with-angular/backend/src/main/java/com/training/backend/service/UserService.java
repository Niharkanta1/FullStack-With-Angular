package com.training.backend.service;

public interface UserService {

}

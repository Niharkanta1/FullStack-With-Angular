package com.training.backend.dto;

import lombok.Data;

@Data
public class LoginBean {
	private String message;
    private String username;
    private String password;
}
